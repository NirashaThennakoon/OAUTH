package com.nirasha.oauth.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.authentication.configuration.GlobalAuthenticationConfigurerAdapter;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class UserConfiguration extends GlobalAuthenticationConfigurerAdapter {

	@Override
	public void init(AuthenticationManagerBuilder auth) throws Exception{
		PasswordEncoder passwordEncoder= PasswordEncoderFactories.createDelegatingPasswordEncoder();
		auth.inMemoryAuthentication()
		.withUser("Nirasha")
		.password(passwordEncoder.encode("pass"))
		.roles("ADMIN","USER").authorities("CAN_READ").and()
		.withUser("saman").password(passwordEncoder.encode("pass")).roles("USER").authorities("CAN_READ");
	}
}
